<?php


    function bing_get($query, $proxy=NULL, $cc="pk")
    {
    
        $query = '%22'.str_replace(' ', '+', $query).'%22';

        $ch = curl_init ();
        $useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";

        curl_setopt ($ch, CURLOPT_URL, "http://www.bing.com/search?q=".($query).'&cc='.$cc);
        curl_setopt ($ch, CURLOPT_USERAGENT, $useragent); // set user agent
        curl_setopt ($ch, CURLOPT_HEADER,false);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt ($ch, CURLOPT_NOBODY,false);
        curl_setopt ($ch, CURLOPT_BINARYTRANSFER,false);
        
        
        $CookieJarFilename = 'cookie.txt';
        
        curl_setopt($ch, CURLOPT_COOKIEJAR, $CookieJarFilename);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $CookieJarFilename);
        
        curl_setopt($ch, CURLOPT_REFERER, 'https://www.yandex.com');

        if ($proxy !== NULL)
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
            
        $result = curl_exec ($ch);
        curl_close($ch);

        return $result;
    }
    
    function bing_parse($data)
    {
        $ret = Array();
        $html = str_get_html($data);

        if ($html)
            foreach($html->find('.b_algo') as $key => $element)
                $ret []= $element->find('h2 a',0)->href;
        
        return $ret;
    }
    
    function bing_go($query, $proxy=NULL, $cc="pk")    
    {
        $data = bing_get($query,$proxy,$cc);
        return bing_parse($data);
    }
    
    
    /*function bing_get_links($query, $proxy=NULL, $cc="pk")
    {
        $query = '%22'.str_replace(' ', '+', $query).'%22';       
        $url = "http://www.bing.com/search?q=".($query).'&cc='.$cc;
        //$cmd = CR_LINKS_PATH." ".($proxy !==NULL ? "-socks-proxy {$proxy} " : '')."-html-numbered-links 1 -http.fake-user-agent \"Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0\" -dump -force-html \"{$url}\"";
        //return `$cmd`;
        
        $f = microtime(TRUE).md5($_SERVER['REMOTE_ADDR']).'.gz';
        $cmd = CR_LINKS_PATH." ".($proxy !==NULL ? "-socks-proxy {$proxy} " : '')." -http.fake-user-agent \"Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0\" -source \"{$url}\" > $f";
        `$cmd`;
        $res = implode('', gzfile($f));
        @unlink($f);
       
        return ($res);
    }*/
        
    