<?php

    function yandex_get($query, $proxy=NULL)
    {

        $query = '%22'.str_replace(' ', '+', $query).'%22';

        $ch = curl_init ();
        $useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";



        curl_setopt ($ch, CURLOPT_URL, "https://www.yandex.com/search/?text=".$query);
        curl_setopt ($ch, CURLOPT_USERAGENT, $useragent); // set user agent
        curl_setopt ($ch, CURLOPT_HEADER,false);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt ($ch, CURLOPT_NOBODY,false);
        curl_setopt ($ch, CURLOPT_BINARYTRANSFER,false);
        
        
        $CookieJarFilename = 'cookie.txt';
        
        curl_setopt($ch, CURLOPT_COOKIEJAR, $CookieJarFilename);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $CookieJarFilename);
        
        curl_setopt($ch, CURLOPT_REFERER, 'https://www.yandex.com');

        if ($proxy !== NULL)
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
            
        //curl_setopt($ch, CURLOPT_PROXY, "http://104.250.98.41:80");

        $result = curl_exec ($ch);
        curl_close($ch);
        
        //if (!preg_match_all('/<ul class="b-results"><div style="clear:both"><a\s+href="([^"]*)"/i', $result, $matches))
        //    return false;

        return $result;
    }
    
 
    
    function yandex_parse($data)
    {
        $ret = Array();
        $html = str_get_html($data);

        if ($html)
        {
            foreach($html->find('.result h3') as $key => $element)
            {
                $url = urldecode($element->find('a',0)->href);
                if (preg_match('/RU\=(.*)\/RK\=/', $url, $match))
                $ret []= $match[1];
            }
        }
        
        return $ret;
    }
    
    function yandex_go($query, $proxy=NULL)    
    {
        $data = yandex_get($query,$proxy);
        return yandex_parse($data);
    }        