<?php


    function dogpile_get ($query, $proxy=NULL)
    {
        $query = urlencode($query);
        $url = "http://www.dogpile.com/search/web?fcoid=417&fcop=topnav&fpid=27&q=%22".$query."%22&ql=";
        
        $ch = curl_init();
        curl_setopt_array($ch, 
            array(
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $url,
                CURLOPT_USERAGENT => "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15",
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded'),
                CURLOPT_HEADER => FALSE,
                CURLOPT_FOLLOWLOCATION => TRUE,
                CURLOPT_REFERER, 'http://www.dogpile.com/'
                
            ));

        if ($proxy !== NULL)
            curl_setopt($ch, CURLOPT_PROXY, $proxy);

        $resp = curl_exec($ch);
        
        curl_close($ch);
        
        return $resp;
    }

/*

    function _dogpile_get($query, $proxy=NULL)
    {
    
        $query = '"'.str_replace(' ', '+', $query).'"';

        $ch = curl_init ();
        $useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";
        
        $url = "http://www.dogpile.com/search/web?q=".($query);
    
    
        curl_setopt ($ch, CURLOPT_URL, $url);
        
        //http://www.dogpile.com/dogpiletestC/search/web?fcoid=114&fcop=topnav&fpid=27&q=".$query."&ql=&qlnk=True
        
        curl_setopt ($ch, CURLOPT_USERAGENT, $useragent); // set user agent
        curl_setopt ($ch, CURLOPT_HEADER,false);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt ($ch, CURLOPT_NOBODY,false);
        curl_setopt ($ch, CURLOPT_BINARYTRANSFER,false);
        
        
        $CookieJarFilename = 'cookie.txt';
        
        curl_setopt($ch, CURLOPT_COOKIEJAR, $CookieJarFilename);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $CookieJarFilename);
        
        curl_setopt($ch, CURLOPT_REFERER, $url);

        if ($proxy !== NULL)
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
            
        $result = curl_exec ($ch);
        curl_close($ch);

        return $result;
    }*/
    
    function dogpile_parse($data)
    {
        $ret = Array();
        $html = str_get_html($data);

        if ($html)
            foreach($html->find('.resultDisplayUrlPane') as $key => $element)
                $ret []= $element->find('a',0)->plaintext;
        
        return $ret;
    }
    
    function dogpile_go($query, $proxy=NULL, $cc="pk")    
    {
        $data = dogpile_get($query,$proxy,$cc);
        return dogpile_parse($data);
    }
    