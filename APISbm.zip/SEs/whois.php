<?php


    function whois_get ($domain, $proxy=NULL)
    {
        $url = "https://whois.domaintools.com/".$domain;
        
        $ch = curl_init();
        curl_setopt_array($ch, 
            array(
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => $url,
                CURLOPT_USERAGENT => "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15",
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => array('Content-Type: application/x-www-form-urlencoded'),
                CURLOPT_HEADER => FALSE,
                CURLOPT_FOLLOWLOCATION => TRUE,
                CURLOPT_REFERER, 'https://whois.domaintools.com'
            )
        );

        if ($proxy !== NULL)
            curl_setopt($ch, CURLOPT_PROXY, $proxy);

        $resp = curl_exec($ch);
        
        curl_close($ch);
        
        return $resp;
    }


    print $w = whois_get('rubikmail.com');
    
    file_put_contents('w.html', $w);