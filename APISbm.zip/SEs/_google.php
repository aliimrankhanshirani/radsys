<?php


    function google_get($query, $proxy=NULL)
    {
    
        $query = '%22'.str_replace(' ', '+', $query).'%22';

        $ch = curl_init ();
        $useragent = "Opera/9.80 (J2ME/MIDP; Opera Mini/4.2.14912/870; U; id) Presto/2.4.15";

        curl_setopt ($ch, CURLOPT_URL, "https://google.com/search?q=".($query));
        curl_setopt ($ch, CURLOPT_USERAGENT, $useragent); // set user agent
        curl_setopt ($ch, CURLOPT_HEADER,false);
        curl_setopt ($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt ($ch, CURLOPT_NOBODY,false);
        curl_setopt ($ch, CURLOPT_BINARYTRANSFER,false);
        
        
        $CookieJarFilename = 'cookie.txt';
        
        curl_setopt($ch, CURLOPT_COOKIEJAR, $CookieJarFilename);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $CookieJarFilename);
        
        curl_setopt($ch, CURLOPT_REFERER, 'https://www.google.com/');

        if ($proxy !== NULL)
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
            
        $result = curl_exec ($ch);
        curl_close($ch);

        return $result;
    }
    
    
    function google_get_links($query, $proxy=NULL)
    {
        $query = '%22'.str_replace(' ', '+', $query).'%22';    
           
        $cmd = CR_LINKS_PATH." ".($proxy !==NULL ? "-socks-proxy {$proxy} " : '')."-html-numbered-links 1 -http.fake-user-agent \"Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0\" -dump -force-html \"http://google.com/search?hl=en&q={$query}\"";
    
        return `$cmd`;
    }
    
    
    //links -socks-proxy 127.0.0.1:9050 -http.referer 1 -http.fake-user-agent "Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0" -dump "http://www.dogpile.com/search/web?q=%22When+asked+to+comment+about+the+presence+of+Osama+bin+Laden+near+the+Pakistan+Military+Academy+in+Kakul%22"
    //links -socks-proxy 127.0.0.1:9050 -http.referer 1 -http.fake-user-agent "Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0" -dump "http://www.dogpile.com/search/web?fcoid=417&fcop=topnav&fpid=27&q=%22When+asked+to+comment+about+the+presence+of+Osama+bin+Laden+near+the+Pakistan+Military+Academy+in+Kakul%22&ql="
    
    