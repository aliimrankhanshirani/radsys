<?php


    const CR_LINKS_PATH = '"C:/Users/Imran/Desktop/Software/Links/links.exe"';
    
    require_once './SEs/simple_html_dom.php';
    
    require_once './SEs/bing.php';
    require_once './SEs/yahoo.php';
    require_once './SEs/dogpile.php';
    require_once './SEs/_google.php';
    require_once './SEs/_yandex.php';

    
    