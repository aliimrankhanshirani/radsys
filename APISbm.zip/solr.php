<?php

    // to index a document
    
    $document = Array(
        "id" => "1977",
        "filename" => "test.docx",
        "text" => "A quick brown fox jumps over the lazy dog",
    );
    
    $var= json_encode($document);

    $protocol = 'http';
    $port = '8983';
    $host = '172.16.3.21';
    $path = '/solr';
    
    $url="http://172.16.3.21:8983/solr/plaghunt/update/json/docs/?commit=true" ;
    print $url;
    
    $username = "";
    $password = "";

    $ch = curl_init();
    $header = array("Content-type:apliation/json; charset=utf-8");
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch,CURLOPT_USERPWD ,"$username:$password");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $var);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLINFO_HEADER_OUT, 1);

    $data = curl_exec($ch);

    if (curl_errno($ch)) {
        print  0 ;
    }
    else {
        print $data;
    }
    curl_close($ch);