<?php

//replace with your query URL
//$url = "http://127.0.0.1:8080/solr/core1/select/?q=*%3A*&start=0&rows=10&wt=json";


//$url = "http://localhost:8983/solr/t1/select?q=*&wt=json&indent=true";





$q = urlencode("Wizarding Holidays with Skyscanner");
echo $url = "http://172.16.0.23:8983/solr/plaghunt3/select?q=content_t:\"$q\"&wt=json&indent=true";

//"http://172.16.0.23:8983/solr/plaghunt3/select?indent=on&q=content_t:\"$q\"&wt=json"

//echo $url = "http://localhost:8983/solr/plaghunt/select?q=text:".$q."&wt=json&indent=true";

//%2Bpopularity:[10%20TO%20*]%20%2B
//Executes the URL and saves the content (json) in the variable.
$content = file_get_contents($url);
if($content) {
  $result = json_decode($content,true);

    //prints the content of array on the page. Instead perform the operation you ae interested.
    //var_dump($result);
    print_r($result);
}
?>