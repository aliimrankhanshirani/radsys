<?php

    require_once 'settings.php';
    
    $q = "When asked to comment about the presence of Osama bin Laden near the Pakistan Military Academy in Kakul";
    $p = "socks5://127.0.0.1:9050"; 
    
    
    //$res = bing_get($q, $p); print_R(bing_parse($res));
    //$res = bing_go($q, $p);  //print_R($res);    

    //$res = yahoo_get($q, $p); print_R(yahoo_parse($res));    
    //$res = yahoo_go($q, $p);  print_R($res);    
    
    $res = dogpile_get($q, $p); 
    
    file_put_contents('dog.txt', $res);
    
    print $res;
    //print_R(dogpile($res));    
    
    die;
    
    $start = microtime(true);
    $res = bing_go($q, $p);  //print_R($res);    
    print "Bing resultes in - " .sprintf("%.2lf", microtime(true) - $start)."\n\n";

    $start = microtime(true);
    $res = yahoo_go($q, $p);  //print_R($res);    
    print "Yahoo resultes in - " .sprintf("%.2lf", microtime(true) - $start)."\n\n";
    
    /*
Bing results in - 2.23
Yahoo results in - 2.78

    */