<?php

    
    $access_key = trim(@$_POST['access_key']);
    
    $arr = Array(
        'parsing_time'    => microtime(true),
        'remaining_files' => 0,
        'status'          => 'none',
        'results'         => Array(),
    );
    
    if ($access_key == '')
    {
        $arr['status'] = 'Invalid Access Key';
        die( json_encode($arr, JSON_PRETTY_PRINT) );
    }
    

    $files = glob("./data/{$access_key}/*.xml");
    
    foreach ($files as $file)
    {
        $data = yandex_parse($file);
        if ($data !== FALSE)
        {
            @unlink($file);
            
            $arr ['results'] []= Array(
                'id'    => intval(basename($file)),
                'found' => $data === -1 ? false : true,
                'urls'  => $data === -1 ? Array() : $data,
            );
        }
        else
            $arr['remaining_files']++;
            
    }
    $arr['parsing_time'] = microtime(true) - $arr['parsing_time'];
    
    if ($arr['remaining_files'] > 0)
        $arr['status'] = 'Ongoing URLS crawling - at system level';
    
    print json_encode($arr, JSON_PRETTY_PRINT);
    
    if ($arr['remaining_files'] == 0)
        shell_exec("rm -rf ./data/$access_key");
    
        

    function yandex_parse($file)
    {
        $data = file_get_contents($file);
        $xml=@simplexml_load_string($data);
        if (!$xml)
            return false;
        
        $json = @json_encode($xml);

        $yummy = json_decode($json, true);
        if (!$yummy)
            return false;

        $group_size=count(@$yummy['response']['results']['grouping']['group']);
        $plagiarismArr = array();

        if ($group_size > 0)
        {
            if (!isAssoc($yummy['response']['results']['grouping']['group']))
            {
                for ($j=0; $j < $group_size; $j++)
                    $plagiarismArr[$j] = $yummy['response']['results']['grouping']['group'][$j]['doc']['url'];
            }
            else
                $plagiarismArr[] = $yummy['response']['results']['grouping']['group']['doc']['url'];
        }
        
        $plagiarismArr = @array_unique($plagiarismArr);
        if (empty($plagiarismArr))
            return -1;
        
        return $plagiarismArr;
    }

    function isAssoc($arr)
    {
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
